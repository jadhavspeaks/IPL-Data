import { useState } from 'react'
import axios from 'axios'
import { SourceBadge, EmptyState, Spinner } from '../components/UI'
import { Search, X, ExternalLink, ChevronDown, ChevronUp, Link } from 'lucide-react'

const SOURCES = ['sharepoint', 'confluence', 'jira']

const PRIORITY_COLORS = {
  highest: 'bg-red-100 text-red-700',
  high:    'bg-orange-100 text-orange-700',
  medium:  'bg-yellow-100 text-yellow-700',
  low:     'bg-blue-100 text-blue-700',
  lowest:  'bg-gray-100 text-gray-500',
}

function KnowledgeCard({ doc }) {
  const e = doc.entities || {}
  const m = doc.metadata || {}
  const hasEntities = (
    e.jira_tickets?.length || e.change_numbers?.length ||
    e.versions?.length || e.dates?.length || e.environments?.length
  )

  if (!hasEntities && !doc.related_docs?.length) return null

  return (
    <div className="mt-3 pt-3 border-t border-gray-100 space-y-2">
      {/* Entity pills */}
      {hasEntities && (
        <div className="flex flex-wrap gap-1.5">
          {e.environments?.map(env => (
            <span key={env} className="badge bg-green-50 text-green-700 text-xs">
              🌐 {env}
            </span>
          ))}
          {e.dates?.slice(0,3).map(d => (
            <span key={d} className="badge bg-blue-50 text-blue-700 text-xs">
              📅 {d}
            </span>
          ))}
          {e.versions?.slice(0,3).map(v => (
            <span key={v} className="badge bg-purple-50 text-purple-700 text-xs">
              🏷 v{v}
            </span>
          ))}
          {e.change_numbers?.slice(0,3).map(c => (
            <span key={c} className="badge bg-orange-50 text-orange-700 text-xs">
              🔄 {c}
            </span>
          ))}
          {e.jira_tickets?.slice(0,5).map(t => (
            <span key={t} className="badge bg-indigo-50 text-indigo-700 text-xs font-mono">
              🎫 {t}
            </span>
          ))}
        </div>
      )}

      {/* Related docs cross-links */}
      {doc.related_docs?.length > 0 && (
        <div>
          <p className="text-xs text-gray-400 mb-1 flex items-center gap-1">
            <Link size={10}/> Related
          </p>
          <div className="space-y-1">
            {doc.related_docs.map((r, i) => (
              <a key={i} href={r.url} target="_blank" rel="noopener noreferrer"
                className="flex items-center gap-2 text-xs text-teal-600 hover:text-teal-800 group">
                <SourceBadge type={r.source_type} />
                <span className="truncate group-hover:underline">{r.title}</span>
                <ExternalLink size={9} className="shrink-0"/>
              </a>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

function ResultCard({ doc }) {
  const [expanded, setExpanded] = useState(false)
  const m = doc.metadata || {}
  const priorityColor = PRIORITY_COLORS[(m.priority || '').toLowerCase()] || 'bg-gray-100 text-gray-500'

  return (
    <div className="card overflow-hidden">
      <div className="p-4">
        {/* Header row */}
        <div className="flex items-start justify-between gap-2 mb-1.5">
          <div className="flex items-center gap-2 flex-wrap">
            <SourceBadge type={doc.source_type} />
            {m.status && (
              <span className="badge bg-gray-100 text-gray-600 text-xs">{m.status}</span>
            )}
            {m.priority && (
              <span className={`badge text-xs ${priorityColor}`}>{m.priority}</span>
            )}
            {m.issue_type && (
              <span className="badge bg-blue-50 text-blue-600 text-xs">{m.issue_type}</span>
            )}
          </div>
          <a href={doc.url} target="_blank" rel="noopener noreferrer"
            className="shrink-0 flex items-center gap-1 text-xs text-teal-600 hover:text-teal-800 font-medium">
            <ExternalLink size={11}/> Open
          </a>
        </div>

        {/* Title */}
        <h3 className="font-semibold text-gray-900 text-sm leading-snug mb-1">
          {doc.title}
        </h3>

        {/* Meta line */}
        <p className="text-xs text-gray-400 mb-2">
          {doc.source}
          {doc.author && ` · by ${doc.author}`}
          {m.assignee && ` · assigned to ${m.assignee}`}
          {doc.updated_at && ` · ${new Date(doc.updated_at).toLocaleDateString()}`}
        </p>

        {/* Content preview */}
        <p className="text-gray-600 text-xs leading-relaxed line-clamp-3">
          {doc.content_preview}
        </p>

        {/* Knowledge card — entities + related docs */}
        <KnowledgeCard doc={doc} />
      </div>

      {/* Expand full content */}
      <div className="border-t border-gray-100">
        <button
          onClick={() => setExpanded(!expanded)}
          className="w-full flex items-center justify-between px-4 py-2 text-xs text-gray-400 hover:bg-gray-50 transition-colors"
        >
          <span>{expanded ? 'Hide content' : 'Show full content'}</span>
          {expanded ? <ChevronUp size={12}/> : <ChevronDown size={12}/>}
        </button>
        {expanded && (
          <div className="px-4 pb-4">
            <div className="bg-gray-50 rounded-lg p-3 text-xs text-gray-700 leading-relaxed max-h-60 overflow-y-auto whitespace-pre-wrap">
              {doc.content_preview}
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default function SearchPage() {
  const [query, setQuery]             = useState('')
  const [sourceFilter, setSourceFilter] = useState('')
  const [results, setResults]         = useState(null)
  const [loading, setLoading]         = useState(false)
  const [page, setPage]               = useState(1)

  const doSearch = async (q = query, src = sourceFilter, p = 1) => {
    if (!q.trim()) return
    setLoading(true)
    try {
      const params = new URLSearchParams({ q, page: p })
      if (src) params.append('source_type', src)
      const res = await axios.get(`/api/search?${params}`)
      setResults(res.data)
      setPage(p)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Search</h1>
        <p className="text-gray-500 text-sm mt-0.5">
          BM25-ranked search across all sources · extracted entities · cross-linked results
        </p>
      </div>

      {/* Search bar */}
      <div className="card p-4 space-y-3">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400"/>
            <input
              type="text"
              className="w-full pl-9 pr-9 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
              placeholder='e.g. "when was feature X deployed to production" or "CHG-12345"'
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={e => e.key === 'Enter' && doSearch()}
            />
            {query && (
              <button onClick={() => { setQuery(''); setResults(null) }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <X size={14}/>
              </button>
            )}
          </div>
          <button className="btn-primary px-6" onClick={() => doSearch()} disabled={loading}>
            {loading ? 'Searching…' : 'Search'}
          </button>
        </div>

        {/* Source filters */}
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs text-gray-500">Filter:</span>
          {['', ...SOURCES].map(src => (
            <button key={src}
              onClick={() => { setSourceFilter(src); if (query) doSearch(query, src) }}
              className={`badge cursor-pointer text-xs px-3 py-1 transition-colors ${
                sourceFilter === src ? 'bg-teal-500 text-white' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
              }`}>
              {src === '' ? 'All sources' : src}
            </button>
          ))}
        </div>
      </div>

      {loading && <div className="flex justify-center py-12"><Spinner/></div>}

      {/* Results */}
      {!loading && results && (
        <div className="space-y-3">
          <p className="text-sm text-gray-500">
            <span className="font-semibold text-gray-900">{results.total?.toLocaleString()}</span> results
            for "<span className="italic">{results.query}</span>"
          </p>

          {results.results?.length === 0
            ? <EmptyState icon="🔍" title="No results" subtitle="Try different keywords or remove the source filter."/>
            : results.results.map(doc => <ResultCard key={doc.id} doc={doc}/>)
          }

          {/* Pagination */}
          {results.total > results.page_size && (
            <div className="flex justify-center gap-2 pt-2">
              <button className="btn-secondary text-sm" disabled={page === 1}
                onClick={() => doSearch(query, sourceFilter, page - 1)}>Previous</button>
              <span className="flex items-center px-4 text-sm text-gray-500">
                Page {page} of {Math.ceil(results.total / results.page_size)}
              </span>
              <button className="btn-secondary text-sm"
                disabled={page >= Math.ceil(results.total / results.page_size)}
                onClick={() => doSearch(query, sourceFilter, page + 1)}>Next</button>
            </div>
          )}
        </div>
      )}

      {!loading && !results && (
        <EmptyState icon="💡" title="Start searching"
          subtitle='Try: "deployment to production" · "CHG-12345" · "release notes v2.0"'/>
      )}
    </div>
  )
}
