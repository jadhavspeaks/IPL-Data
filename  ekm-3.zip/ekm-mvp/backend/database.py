from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import IndexModel, TEXT, ASCENDING, DESCENDING
from config import get_settings
import logging

logger = logging.getLogger(__name__)
settings = get_settings()

client: AsyncIOMotorClient = None
db = None


async def connect_db():
    global client, db
    client = AsyncIOMotorClient(settings.mongo_uri)
    db = client[settings.mongo_db]
    await client.admin.command("ping")
    await create_indexes()
    logger.info(f"Connected to MongoDB: {settings.mongo_uri}")


async def close_db():
    global client
    if client:
        client.close()
        logger.info("MongoDB connection closed")


async def create_indexes():
    """Create all required indexes on startup."""
    docs = db.documents

    await docs.create_indexes([
        # Full-text search across title + content + tags
        IndexModel(
            [("title", TEXT), ("content", TEXT), ("tags", TEXT)],
            name="text_search",
            weights={"title": 10, "tags": 5, "content": 1}
        ),
        # Filter by source type
        IndexModel([("source_type", ASCENDING)], name="source_type_idx"),
        # Filter by source
        IndexModel([("source", ASCENDING)], name="source_idx"),
        # Latest first
        IndexModel([("ingested_at", DESCENDING)], name="ingested_at_idx"),
        # Incremental sync — filter by updated_at
        IndexModel([("updated_at", DESCENDING)], name="updated_at_idx"),
        # Unique upsert key — prevents duplicates across syncs
        IndexModel(
            [("source_type", ASCENDING), ("external_id", ASCENDING)],
            unique=True, name="unique_doc_idx"
        ),
        # Entity indexes — fast lookup by ticket/change number
        IndexModel(
            [("entities.jira_tickets", ASCENDING)],
            name="entity_tickets_idx", sparse=True
        ),
        IndexModel(
            [("entities.change_numbers", ASCENDING)],
            name="entity_change_idx", sparse=True
        ),
    ])

    # Sync logs
    await db.sync_logs.create_indexes([
        IndexModel([("source_type", ASCENDING)], name="sync_log_source_idx"),
        IndexModel([("started_at", DESCENDING)], name="sync_log_time_idx"),
    ])

    # Sync state — stores last sync timestamp per source
    await db.sync_state.create_indexes([
        IndexModel(
            [("source_type", ASCENDING)],
            unique=True, name="sync_state_source_idx"
        ),
    ])

    logger.info("MongoDB indexes created")


async def get_last_sync(source_type: str):
    """Get the last successful sync timestamp for a source. Returns None if never synced."""
    state = await db.sync_state.find_one({"source_type": source_type})
    return state.get("last_sync_at") if state else None


async def set_last_sync(source_type: str, timestamp):
    """Store the last successful sync timestamp for a source."""
    await db.sync_state.update_one(
        {"source_type": source_type},
        {"$set": {"source_type": source_type, "last_sync_at": timestamp}},
        upsert=True,
    )


def get_db():
    return db
