"""
Search Route
─────────────
GET /api/search?q=...

Pipeline:
1. MongoDB $text pre-filter  — fast candidate retrieval
2. BM25 re-ranking           — better relevance than raw TF-IDF
3. Cross-linking             — attach related Jira/Confluence docs via shared entities
4. Knowledge card assembly   — structured view for release/deployment queries
"""

import logging
from fastapi import APIRouter, Query
from database import get_db
from models import SearchResponse, DocumentOut
from config import get_settings
from utils.bm25 import rerank_bm25
from utils.extractor import extract_entities

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/search", tags=["search"])
settings = get_settings()

# How many candidates to fetch from Mongo before BM25 re-ranking
CANDIDATE_POOL = 200


async def _find_related(db, doc: dict) -> list[dict]:
    """
    Find related documents by matching extracted entities.
    e.g. A Confluence release note mentioning PROJ-123 will link to that Jira issue.
    """
    entities = doc.get("entities") or {}
    tickets  = entities.get("jira_tickets", [])
    changes  = entities.get("change_numbers", [])
    related  = []

    if not tickets and not changes:
        return []

    query_parts = []
    if tickets:
        query_parts.append({"entities.jira_tickets": {"$in": tickets}})
    if changes:
        query_parts.append({"entities.change_numbers": {"$in": changes}})

    cursor = db.documents.find(
        {
            "$or": query_parts,
            "external_id": {"$ne": doc.get("external_id")},   # exclude self
        },
        {
            "title": 1, "url": 1, "source": 1, "source_type": 1,
            "author": 1, "metadata": 1, "entities": 1, "updated_at": 1,
        }
    ).limit(5)

    async for r in cursor:
        related.append({
            "id":          str(r["_id"]),
            "title":       r.get("title", ""),
            "url":         r.get("url", ""),
            "source":      r.get("source", ""),
            "source_type": r.get("source_type", ""),
            "author":      r.get("author"),
            "metadata":    r.get("metadata", {}),
            "entities":    r.get("entities", {}),
        })

    return related


def _doc_to_out(doc: dict) -> dict:
    content = doc.get("content", "")
    return {
        "id":              str(doc["_id"]),
        "external_id":     doc.get("external_id", ""),
        "source_type":     doc.get("source_type", ""),
        "source":          doc.get("source", ""),
        "title":           doc.get("title", ""),
        "content_preview": content[:400] + ("…" if len(content) > 400 else ""),
        "url":             doc.get("url", ""),
        "author":          doc.get("author"),
        "tags":            doc.get("tags", []),
        "metadata":        doc.get("metadata", {}),
        "entities":        doc.get("entities", {}),
        "ingested_at":     doc.get("ingested_at"),
        "updated_at":      doc.get("updated_at"),
        "bm25_score":      doc.get("bm25_score"),
        "related_docs":    doc.get("related_docs", []),
    }


@router.get("")
async def search(
    q:           str           = Query(..., min_length=1),
    source_type: str | None    = Query(None),
    page:        int           = Query(1, ge=1),
    page_size:   int | None    = Query(None),
):
    db = get_db()
    page_size = page_size or settings.max_results_per_page
    skip = (page - 1) * page_size

    # ── Step 1: MongoDB text search — fast candidate pool ─────────────────────
    match_filter: dict = {"$text": {"$search": q}}
    if source_type:
        match_filter["source_type"] = source_type

    # Also check if the query looks like a ticket/change ref — do entity lookup too
    query_entities = extract_entities(q)
    entity_ids = []

    if query_entities.get("jira_tickets") or query_entities.get("change_numbers"):
        entity_filter_parts = []
        if query_entities.get("jira_tickets"):
            entity_filter_parts.append(
                {"entities.jira_tickets": {"$in": query_entities["jira_tickets"]}}
            )
        if query_entities.get("change_numbers"):
            entity_filter_parts.append(
                {"entities.change_numbers": {"$in": query_entities["change_numbers"]}}
            )
        entity_cursor = db.documents.find(
            {"$or": entity_filter_parts},
            {"title":1,"content":1,"source":1,"source_type":1,"url":1,
             "author":1,"tags":1,"metadata":1,"entities":1,
             "ingested_at":1,"updated_at":1,"external_id":1}
        ).limit(20)
        entity_docs = await entity_cursor.to_list(length=20)
        entity_ids = [str(d["_id"]) for d in entity_docs]
    else:
        entity_docs = []

    # Text search candidates
    cursor = db.documents.find(
        match_filter,
        {"title":1,"content":1,"source":1,"source_type":1,"url":1,
         "author":1,"tags":1,"metadata":1,"entities":1,
         "ingested_at":1,"updated_at":1,"external_id":1}
    ).limit(CANDIDATE_POOL)
    text_candidates = await cursor.to_list(length=CANDIDATE_POOL)

    # Merge — entity docs first, then text candidates (deduplicated)
    seen_ids = set(entity_ids)
    all_candidates = list(entity_docs)
    for doc in text_candidates:
        if str(doc["_id"]) not in seen_ids:
            all_candidates.append(doc)
            seen_ids.add(str(doc["_id"]))

    total = len(all_candidates)

    if not all_candidates:
        return {
            "query": q, "total": 0, "results": [],
            "page": page, "page_size": page_size
        }

    # ── Step 2: BM25 re-ranking ───────────────────────────────────────────────
    ranked = rerank_bm25(q, all_candidates)

    # ── Step 3: Paginate ──────────────────────────────────────────────────────
    page_docs = ranked[skip: skip + page_size]

    # ── Step 4: Cross-link related documents ─────────────────────────────────
    results = []
    for doc in page_docs:
        related = await _find_related(db, doc)
        doc["related_docs"] = related
        results.append(_doc_to_out(doc))

    return {
        "query":     q,
        "total":     total,
        "results":   results,
        "page":      page,
        "page_size": page_size,
    }
