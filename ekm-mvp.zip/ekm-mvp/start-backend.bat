@echo off
:: ─── EKM Backend — Local Setup & Run (Windows) ───────────────────────────────
cd /d "%~dp0backend"

echo.
echo ╔══════════════════════════════════════╗
echo ║   EKM Backend — Local Setup          ║
echo ╚══════════════════════════════════════╝
echo.

:: Check Python
python --version >nul 2>&1
if errorlevel 1 (
    echo ✗ Python not found. Install from https://python.org ^(3.11+^)
    pause
    exit /b 1
)
echo ✓ Python found

:: Create venv
if not exist "venv" (
    echo → Creating virtual environment...
    python -m venv venv
)

:: Activate
call venv\Scripts\activate.bat
echo ✓ Virtual environment activated

:: Install deps
echo → Installing dependencies...
pip install -q --upgrade pip
pip install -q -r requirements.txt
echo ✓ Dependencies installed

:: Check .env
if not exist ".env" (
    echo.
    echo ⚠  No .env found in backend\
    copy ..\env.example .env
    echo → Created backend\.env from template - edit it before continuing
    pause
    exit /b 1
)
echo ✓ .env found

:: Run
echo.
echo → Starting FastAPI on http://localhost:8000
echo    API docs: http://localhost:8000/docs
echo.
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
