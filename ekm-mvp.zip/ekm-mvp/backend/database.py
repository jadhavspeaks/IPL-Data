from motor.motor_asyncio import AsyncIOMotorClient
from pymongo import IndexModel, TEXT, ASCENDING, DESCENDING
from config import get_settings
import logging

logger = logging.getLogger(__name__)
settings = get_settings()

client: AsyncIOMotorClient = None
db = None


async def connect_db():
    global client, db
    client = AsyncIOMotorClient(settings.mongo_uri)
    db = client[settings.mongo_db]
    await create_indexes()
    await client.admin.command("ping")
    logger.info(f"Connected to MongoDB: {settings.mongo_uri}")


async def close_db():
    global client
    if client:
        client.close()
        logger.info("MongoDB connection closed")


async def create_indexes():
    """Create all required indexes on startup."""
    docs = db.documents

    await docs.create_indexes([
        # Full-text search across title + content + tags
        IndexModel([("title", TEXT), ("content", TEXT), ("tags", TEXT)],
                   name="text_search", weights={"title": 10, "tags": 5, "content": 1}),
        # Filter by source
        IndexModel([("source", ASCENDING)], name="source_idx"),
        # Filter by source_type (sharepoint / confluence / jira)
        IndexModel([("source_type", ASCENDING)], name="source_type_idx"),
        # Latest first
        IndexModel([("ingested_at", DESCENDING)], name="ingested_at_idx"),
        # Upsert key — unique per document per source
        IndexModel([("source_type", ASCENDING), ("external_id", ASCENDING)],
                   unique=True, name="unique_doc_idx"),
    ])

    # Sync log collection
    await db.sync_logs.create_indexes([
        IndexModel([("source_type", ASCENDING)], name="sync_log_source_idx"),
        IndexModel([("started_at", DESCENDING)], name="sync_log_time_idx"),
    ])

    logger.info("MongoDB indexes created")


def get_db():
    return db
