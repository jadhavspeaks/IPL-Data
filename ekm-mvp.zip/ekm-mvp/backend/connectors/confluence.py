"""
Confluence Connector
─────────────────────
Uses Atlassian Python API with basic auth (email + API token).
Pulls pages from configured spaces, strips HTML to plain text for indexing.

Steps to get API token:
  https://id.atlassian.com/manage-profile/security/api-tokens
"""

import logging
import re
from datetime import datetime
from atlassian import Confluence
from config import get_settings
from models import Document, SourceType

logger = logging.getLogger(__name__)
settings = get_settings()


def _html_to_text(html: str) -> str:
    """Strip HTML tags → plain text for search indexing."""
    text = re.sub(r"<[^>]+>", " ", html or "")
    text = re.sub(r"&nbsp;", " ", text)
    text = re.sub(r"&amp;", "&", text)
    text = re.sub(r"&lt;", "<", text)
    text = re.sub(r"&gt;", ">", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _get_client() -> Confluence | None:
    if not all([settings.confluence_url, settings.confluence_username,
                settings.confluence_api_token]):
        logger.warning("Confluence credentials not configured — skipping")
        return None
    return Confluence(
        url=settings.confluence_url,
        username=settings.confluence_username,
        password=settings.confluence_api_token,
        cloud=True,
    )


async def fetch_documents() -> list[Document]:
    """Fetch all pages from configured Confluence spaces."""
    client = _get_client()
    if not client:
        return []

    spaces = settings.confluence_space_list
    if not spaces:
        # Fall back to all spaces the user can access
        try:
            all_spaces = client.get_all_spaces(limit=50)
            spaces = [s["key"] for s in all_spaces.get("results", [])]
        except Exception as e:
            logger.error(f"Could not list Confluence spaces: {e}")
            return []

    documents = []

    for space_key in spaces:
        try:
            start = 0
            limit = 50
            while True:
                pages = client.get_all_pages_from_space(
                    space=space_key,
                    start=start,
                    limit=limit,
                    expand="body.storage,version,ancestors,metadata.labels",
                )
                if not pages:
                    break

                for page in pages:
                    body_html = (
                        page.get("body", {})
                            .get("storage", {})
                            .get("value", "")
                    )
                    plain_text = _html_to_text(body_html)

                    # Labels → tags
                    labels = (
                        page.get("metadata", {})
                            .get("labels", {})
                            .get("results", [])
                    )
                    tags = ["confluence", space_key.lower()] + [
                        l["name"] for l in labels
                    ]

                    version_info = page.get("version", {})
                    author_info = version_info.get("by", {})

                    # Build URL
                    page_url = (
                        f"{settings.confluence_url.rstrip('/')}"
                        f"/wiki/spaces/{space_key}/pages/{page['id']}"
                    )

                    doc = Document(
                        external_id=page["id"],
                        source_type=SourceType.CONFLUENCE,
                        source=f"Confluence / {space_key}",
                        title=page.get("title", "Untitled"),
                        content=plain_text,
                        url=page_url,
                        author=author_info.get("displayName"),
                        tags=tags,
                        metadata={
                            "space_key": space_key,
                            "version": version_info.get("number"),
                            "status": page.get("status"),
                            "ancestors": [
                                a.get("title") for a in page.get("ancestors", [])
                            ],
                        },
                        updated_at=datetime.fromisoformat(
                            version_info["when"].replace("Z", "+00:00")
                        ) if version_info.get("when") else None,
                    )
                    documents.append(doc)

                if len(pages) < limit:
                    break
                start += limit

            logger.info(f"Confluence space {space_key}: fetched pages")

        except Exception as e:
            logger.error(f"Confluence error for space {space_key}: {e}")
            continue

    logger.info(f"Confluence: total {len(documents)} documents fetched")
    return documents
