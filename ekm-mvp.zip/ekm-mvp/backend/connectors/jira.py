"""
Jira Connector
───────────────
Uses Atlassian Python API with basic auth (email + API token).
Pulls issues (with comments) from configured projects.
Indexes: summary + description + comments as combined content.

Steps to get API token:
  https://id.atlassian.com/manage-profile/security/api-tokens
"""

import logging
from datetime import datetime
from atlassian import Jira
from config import get_settings
from models import Document, SourceType

logger = logging.getLogger(__name__)
settings = get_settings()


def _get_client() -> Jira | None:
    if not all([settings.jira_url, settings.jira_username, settings.jira_api_token]):
        logger.warning("Jira credentials not configured — skipping")
        return None
    return Jira(
        url=settings.jira_url,
        username=settings.jira_username,
        password=settings.jira_api_token,
        cloud=True,
    )


def _safe_text(val) -> str:
    """Safely extract text from Jira field (may be None, str, or dict)."""
    if val is None:
        return ""
    if isinstance(val, str):
        return val
    if isinstance(val, dict):
        return val.get("content", "") or str(val)
    return str(val)


def _extract_comments(issue: dict) -> str:
    """Combine all comments into a single string."""
    comments = (
        issue.get("fields", {})
             .get("comment", {})
             .get("comments", [])
    )
    parts = []
    for c in comments:
        body = c.get("body", "")
        author = c.get("author", {}).get("displayName", "")
        if isinstance(body, dict):
            # Jira Cloud uses Atlassian Document Format (ADF)
            body = _adf_to_text(body)
        if body:
            parts.append(f"[{author}]: {body}")
    return "\n".join(parts)


def _adf_to_text(adf: dict) -> str:
    """Naively extract plain text from Atlassian Document Format."""
    texts = []

    def walk(node):
        if isinstance(node, dict):
            if node.get("type") == "text":
                texts.append(node.get("text", ""))
            for child in node.get("content", []):
                walk(child)
        elif isinstance(node, list):
            for item in node:
                walk(item)

    walk(adf)
    return " ".join(texts)


async def fetch_documents() -> list[Document]:
    """Fetch all issues from configured Jira projects."""
    client = _get_client()
    if not client:
        return []

    projects = settings.jira_project_list
    if not projects:
        try:
            all_projects = client.projects()
            projects = [p["key"] for p in all_projects[:10]]  # cap at 10 for MVP
        except Exception as e:
            logger.error(f"Could not list Jira projects: {e}")
            return []

    documents = []

    for project_key in projects:
        try:
            start = 0
            max_results = 50

            while True:
                jql = f"project = {project_key} ORDER BY updated DESC"
                result = client.jql(
                    jql,
                    start=start,
                    limit=max_results,
                    fields=[
                        "summary", "description", "issuetype", "status",
                        "priority", "assignee", "reporter", "labels",
                        "comment", "created", "updated", "components",
                        "fixVersions",
                    ],
                )
                issues = result.get("issues", [])
                if not issues:
                    break

                for issue in issues:
                    fields = issue.get("fields", {})

                    desc = fields.get("description") or ""
                    if isinstance(desc, dict):
                        desc = _adf_to_text(desc)

                    comments = _extract_comments(issue)
                    full_content = "\n\n".join(filter(None, [desc, comments]))

                    labels = ["jira", project_key.lower()]
                    labels += [l for l in (fields.get("labels") or [])]
                    issue_type = fields.get("issuetype", {}).get("name", "")
                    if issue_type:
                        labels.append(issue_type.lower())

                    assignee = fields.get("assignee") or {}
                    reporter = fields.get("reporter") or {}

                    issue_url = (
                        f"{settings.jira_url.rstrip('/')}"
                        f"/browse/{issue['key']}"
                    )

                    updated_str = fields.get("updated")
                    updated_at = None
                    if updated_str:
                        try:
                            updated_at = datetime.fromisoformat(
                                updated_str.replace("Z", "+00:00")
                            )
                        except Exception:
                            pass

                    doc = Document(
                        external_id=issue["id"],
                        source_type=SourceType.JIRA,
                        source=f"Jira / {project_key}",
                        title=f"[{issue['key']}] {fields.get('summary', 'No Summary')}",
                        content=full_content,
                        url=issue_url,
                        author=reporter.get("displayName"),
                        tags=labels,
                        metadata={
                            "issue_key": issue["key"],
                            "project": project_key,
                            "issue_type": issue_type,
                            "status": fields.get("status", {}).get("name"),
                            "priority": fields.get("priority", {}).get("name"),
                            "assignee": assignee.get("displayName"),
                            "components": [
                                c["name"] for c in (fields.get("components") or [])
                            ],
                            "fix_versions": [
                                v["name"] for v in (fields.get("fixVersions") or [])
                            ],
                            "comment_count": (
                                fields.get("comment", {}).get("total", 0)
                            ),
                        },
                        updated_at=updated_at,
                    )
                    documents.append(doc)

                if len(issues) < max_results:
                    break
                start += max_results

            logger.info(f"Jira project {project_key}: fetched issues")

        except Exception as e:
            logger.error(f"Jira error for project {project_key}: {e}")
            continue

    logger.info(f"Jira: total {len(documents)} documents fetched")
    return documents
