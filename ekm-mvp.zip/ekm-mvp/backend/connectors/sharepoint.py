"""
SharePoint Connector
────────────────────
Uses MSAL (Microsoft Authentication Library) with client credentials flow
to authenticate as an Azure AD App Registration, then pulls pages and
documents from a SharePoint site via Microsoft Graph API.

Required Azure AD permissions:
  - Sites.Read.All
  - Files.Read.All
"""

import logging
import httpx
import msal
from datetime import datetime, timezone
from config import get_settings
from models import Document, SourceType

logger = logging.getLogger(__name__)
settings = get_settings()

GRAPH_BASE = "https://graph.microsoft.com/v1.0"


def _get_access_token() -> str | None:
    """Acquire an OAuth2 token using client credentials (app-only auth)."""
    if not all([settings.sharepoint_tenant_id,
                settings.sharepoint_client_id,
                settings.sharepoint_client_secret]):
        logger.warning("SharePoint credentials not configured — skipping")
        return None

    authority = f"https://login.microsoftonline.com/{settings.sharepoint_tenant_id}"
    app = msal.ConfidentialClientApplication(
        settings.sharepoint_client_id,
        authority=authority,
        client_credential=settings.sharepoint_client_secret,
    )
    result = app.acquire_token_for_client(scopes=["https://graph.microsoft.com/.default"])
    if "access_token" in result:
        return result["access_token"]
    logger.error(f"SharePoint auth failed: {result.get('error_description')}")
    return None


def _extract_site_id(token: str, site_url: str) -> str | None:
    """Resolve SharePoint site URL → Graph site ID."""
    # e.g. https://contoso.sharepoint.com/sites/mysite
    parts = site_url.replace("https://", "").split("/")
    hostname = parts[0]
    site_path = "/".join(parts[1:])

    url = f"{GRAPH_BASE}/sites/{hostname}:/{site_path}"
    resp = httpx.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=30)
    if resp.status_code == 200:
        return resp.json().get("id")
    logger.error(f"Could not resolve SharePoint site ID: {resp.text}")
    return None


def _get_site_pages(token: str, site_id: str) -> list[dict]:
    """Fetch all SharePoint pages from the site pages library."""
    url = f"{GRAPH_BASE}/sites/{site_id}/pages"
    headers = {"Authorization": f"Bearer {token}"}
    pages = []

    while url:
        resp = httpx.get(url, headers=headers, timeout=30)
        if resp.status_code != 200:
            logger.error(f"Error fetching SharePoint pages: {resp.text}")
            break
        data = resp.json()
        pages.extend(data.get("value", []))
        url = data.get("@odata.nextLink")   # pagination

    return pages


def _get_drive_files(token: str, site_id: str) -> list[dict]:
    """Fetch Word/PDF documents from the default drive (document library)."""
    url = f"{GRAPH_BASE}/sites/{site_id}/drive/root/children"
    headers = {"Authorization": f"Bearer {token}"}
    files = []

    while url:
        resp = httpx.get(url, headers=headers, timeout=30)
        if resp.status_code != 200:
            break
        data = resp.json()
        for item in data.get("value", []):
            # Only index text-based files
            name = item.get("name", "")
            if any(name.endswith(ext) for ext in [".docx", ".txt", ".md", ".pdf"]):
                files.append(item)
        url = data.get("@odata.nextLink")

    return files


async def fetch_documents() -> list[Document]:
    """Main entry point — returns all SharePoint documents as normalized Documents."""
    token = _get_access_token()
    if not token:
        return []

    site_id = _extract_site_id(token, settings.sharepoint_site_url)
    if not site_id:
        return []

    documents = []
    site_display = settings.sharepoint_site_url.split("/")[-1]

    # ── Site Pages ─────────────────────────────────────────────────────────
    try:
        pages = _get_site_pages(token, site_id)
        for page in pages:
            doc = Document(
                external_id=page.get("id", ""),
                source_type=SourceType.SHAREPOINT,
                source=f"SharePoint / {site_display}",
                title=page.get("title", "Untitled Page"),
                content=page.get("description", "") or "",
                url=page.get("webUrl", ""),
                author=page.get("lastModifiedBy", {}).get("user", {}).get("displayName"),
                tags=["sharepoint", "page"],
                metadata={
                    "content_type": "page",
                    "created": page.get("createdDateTime"),
                    "modified": page.get("lastModifiedDateTime"),
                },
                updated_at=datetime.fromisoformat(
                    page["lastModifiedDateTime"].replace("Z", "+00:00")
                ) if page.get("lastModifiedDateTime") else None,
            )
            documents.append(doc)
        logger.info(f"SharePoint: fetched {len(pages)} pages")
    except Exception as e:
        logger.error(f"SharePoint pages error: {e}")

    # ── Drive Files ────────────────────────────────────────────────────────
    try:
        files = _get_drive_files(token, site_id)
        for f in files:
            doc = Document(
                external_id=f.get("id", ""),
                source_type=SourceType.SHAREPOINT,
                source=f"SharePoint / {site_display}",
                title=f.get("name", "Untitled File"),
                content=f.get("description", "") or f.get("name", ""),
                url=f.get("webUrl", ""),
                author=f.get("lastModifiedBy", {}).get("user", {}).get("displayName"),
                tags=["sharepoint", "file", f.get("name", "").split(".")[-1]],
                metadata={
                    "content_type": "file",
                    "size": f.get("size"),
                    "mime_type": f.get("file", {}).get("mimeType"),
                    "modified": f.get("lastModifiedDateTime"),
                },
                updated_at=datetime.fromisoformat(
                    f["lastModifiedDateTime"].replace("Z", "+00:00")
                ) if f.get("lastModifiedDateTime") else None,
            )
            documents.append(doc)
        logger.info(f"SharePoint: fetched {len(files)} files")
    except Exception as e:
        logger.error(f"SharePoint files error: {e}")

    return documents
