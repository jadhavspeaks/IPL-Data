from fastapi import APIRouter, Query, Depends
from database import get_db
from models import SearchResponse, DocumentOut
from config import get_settings
from bson import ObjectId

router = APIRouter(prefix="/api/search", tags=["search"])
settings = get_settings()


def _doc_to_out(doc: dict) -> DocumentOut:
    content = doc.get("content", "")
    return DocumentOut(
        id=str(doc["_id"]),
        external_id=doc.get("external_id", ""),
        source_type=doc.get("source_type", ""),
        source=doc.get("source", ""),
        title=doc.get("title", ""),
        content_preview=content[:300] + ("…" if len(content) > 300 else ""),
        url=doc.get("url", ""),
        author=doc.get("author"),
        tags=doc.get("tags", []),
        metadata=doc.get("metadata", {}),
        ingested_at=doc.get("ingested_at"),
        updated_at=doc.get("updated_at"),
        score=doc.get("score"),
    )


@router.get("", response_model=SearchResponse)
async def search(
    q: str = Query(..., min_length=1, description="Search query"),
    source_type: str | None = Query(None, description="Filter by source: sharepoint, confluence, jira"),
    page: int = Query(1, ge=1),
    page_size: int = Query(None),
):
    db = get_db()
    page_size = page_size or settings.max_results_per_page
    skip = (page - 1) * page_size

    # Build match filter
    match_filter: dict = {"$text": {"$search": q}}
    if source_type:
        match_filter["source_type"] = source_type

    pipeline = [
        {"$match": match_filter},
        {"$addFields": {"score": {"$meta": "textScore"}}},
        {"$sort": {"score": -1, "ingested_at": -1}},
        {"$facet": {
            "results": [{"$skip": skip}, {"$limit": page_size}],
            "total": [{"$count": "count"}],
        }},
    ]

    cursor = db.documents.aggregate(pipeline)
    data = await cursor.to_list(length=1)

    if not data:
        return SearchResponse(query=q, total=0, results=[], page=page, page_size=page_size)

    facet = data[0]
    total = facet["total"][0]["count"] if facet["total"] else 0
    results = [_doc_to_out(d) for d in facet["results"]]

    return SearchResponse(query=q, total=total, results=results, page=page, page_size=page_size)
