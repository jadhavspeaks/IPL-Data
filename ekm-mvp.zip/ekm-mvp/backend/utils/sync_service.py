"""
Sync Service
─────────────
Orchestrates pulling documents from all connectors and upserting
them into MongoDB. Tracks sync status per source in sync_logs collection.
"""

import logging
from datetime import datetime, timezone
from database import get_db
from models import Document, SourceType, SyncStatus
from connectors import sharepoint, confluence, jira, servicenow

logger = logging.getLogger(__name__)

CONNECTORS = {
    SourceType.SHAREPOINT: sharepoint.fetch_documents,
    SourceType.CONFLUENCE: confluence.fetch_documents,
    SourceType.JIRA: jira.fetch_documents,
    # SourceType.SERVICENOW: servicenow.fetch_documents,  # future scope
}


async def upsert_documents(documents: list[Document]) -> tuple[int, int]:
    """Upsert documents into MongoDB. Returns (added, updated) counts."""
    db = get_db()
    added = updated = 0

    for doc in documents:
        doc_dict = doc.model_dump()
        doc_dict["ingested_at"] = datetime.now(timezone.utc)

        result = await db.documents.update_one(
            {
                "source_type": doc.source_type,
                "external_id": doc.external_id,
            },
            {"$set": doc_dict},
            upsert=True,
        )

        if result.upserted_id:
            added += 1
        elif result.modified_count:
            updated += 1

    return added, updated


async def run_sync(source_type: SourceType | None = None) -> dict:
    """
    Run sync for one or all sources.
    Returns a summary dict with results per source.
    """
    db = get_db()
    sources_to_sync = (
        [source_type] if source_type else list(CONNECTORS.keys())
    )

    results = {}

    for src in sources_to_sync:
        log = {
            "source_type": src,
            "status": SyncStatus.RUNNING,
            "started_at": datetime.now(timezone.utc),
            "docs_added": 0,
            "docs_updated": 0,
            "error_message": None,
        }

        # Write "running" status immediately
        log_result = await db.sync_logs.insert_one(log.copy())
        log_id = log_result.inserted_id

        try:
            fetch_fn = CONNECTORS[src]
            documents = await fetch_fn()

            added, updated = await upsert_documents(documents)

            log.update({
                "status": SyncStatus.SUCCESS,
                "finished_at": datetime.now(timezone.utc),
                "docs_added": added,
                "docs_updated": updated,
            })
            results[src] = {"status": "success", "added": added, "updated": updated}
            logger.info(f"Sync {src}: +{added} added, ~{updated} updated")

        except Exception as e:
            error_msg = str(e)
            log.update({
                "status": SyncStatus.FAILED,
                "finished_at": datetime.now(timezone.utc),
                "error_message": error_msg,
            })
            results[src] = {"status": "failed", "error": error_msg}
            logger.error(f"Sync {src} failed: {e}")

        # Update the log record
        await db.sync_logs.update_one(
            {"_id": log_id},
            {"$set": {
                "status": log["status"],
                "finished_at": log["finished_at"],
                "docs_added": log["docs_added"],
                "docs_updated": log["docs_updated"],
                "error_message": log["error_message"],
            }},
        )

    return results
