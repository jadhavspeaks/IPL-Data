from pydantic_settings import BaseSettings
from functools import lru_cache


class Settings(BaseSettings):
    # MongoDB — point at your existing instance
    mongo_uri: str = "mongodb://localhost:27017/ekm"
    mongo_db: str = "ekm"

    # SharePoint
    sharepoint_tenant_id: str = ""
    sharepoint_client_id: str = ""
    sharepoint_client_secret: str = ""
    sharepoint_site_url: str = ""

    # Confluence
    confluence_url: str = ""
    confluence_username: str = ""
    confluence_api_token: str = ""
    confluence_spaces: str = ""  # comma-separated

    # Jira
    jira_url: str = ""
    jira_username: str = ""
    jira_api_token: str = ""
    jira_projects: str = ""  # comma-separated

    # App
    sync_interval_minutes: int = 60
    max_results_per_page: int = 20

    @property
    def confluence_space_list(self) -> list[str]:
        return [s.strip() for s in self.confluence_spaces.split(",") if s.strip()]

    @property
    def jira_project_list(self) -> list[str]:
        return [p.strip() for p in self.jira_projects.split(",") if p.strip()]

    class Config:
        env_file = ".env"
        extra = "ignore"


@lru_cache
def get_settings() -> Settings:
    return Settings()
