<div align="center">

<img src="https://img.shields.io/badge/Python-3.11+-3776AB?style=for-the-badge&logo=python&logoColor=white"/>
<img src="https://img.shields.io/badge/FastAPI-0.111-009688?style=for-the-badge&logo=fastapi&logoColor=white"/>
<img src="https://img.shields.io/badge/React-18-61DAFB?style=for-the-badge&logo=react&logoColor=black"/>
<img src="https://img.shields.io/badge/MongoDB-7.0-47A248?style=for-the-badge&logo=mongodb&logoColor=white"/>
<img src="https://img.shields.io/badge/Status-MVP-F4A261?style=for-the-badge"/>

# 🧠 Enterprise Knowledge Management (EKM)

**One search. Every knowledge source. Instant answers.**

EKM is an open-source MVP that pulls documents from **SharePoint**, **Confluence**, and **Jira** into a unified MongoDB-backed search engine — with a clean React dashboard to search, browse, and sync all your knowledge sources in one place.

[Features](#-features) · [Architecture](#-architecture) · [Quick Start](#-quick-start) · [Configuration](#-configuration) · [API Reference](#-api-reference) · [Roadmap](#-roadmap)

</div>

---

## 📋 Table of Contents

- [Why EKM?](#-why-ekm)
- [What Is This?](#-what-is-this)
- [Features](#-features)
- [Architecture](#-architecture)
- [Project Structure](#-project-structure)
- [Quick Start](#-quick-start)
- [Configuration](#-configuration)
- [Getting Credentials](#-getting-credentials)
- [Running the App](#-running-the-app)
- [API Reference](#-api-reference)
- [Code Walkthrough](#-code-walkthrough)
- [Screenshots](#-screenshots)
- [Roadmap & Next Steps](#-roadmap--next-steps)
- [Contributing](#-contributing)

---

## 💡 Why EKM?

> Employees at large organisations spend **up to 20% of their working week** just searching for information — that's one full day per person, per week, wasted.

Knowledge lives in silos. Your engineers are in Jira. Your processes are in Confluence. Your policies are in SharePoint. When someone needs an answer, they search three different tools, skim dozens of results, and still might not find what they need.

**EKM fixes this.** It:

- Pulls all your knowledge into one place automatically
- Lets anyone search across every source with a single query
- Shows relevance-ranked results with source attribution
- Links directly back to the original document
- Runs a background sync so everything stays fresh

---

## 🔍 What Is This?

EKM is a **full-stack MVP** consisting of:

| Component | Description |
|-----------|-------------|
| **Python connectors** | Authenticate to SharePoint, Confluence, and Jira and pull documents incrementally |
| **FastAPI backend** | REST API for search, sync, and document browsing |
| **MongoDB** | Stores all indexed documents with full-text search indexes |
| **React dashboard** | Four-page UI — Dashboard, Search, Documents, and sync controls |
| **APScheduler** | Runs automatic background syncs on a configurable interval |

It is intentionally an **MVP** — production-ready in structure, but lightweight enough to run locally in under 5 minutes.

---

## ✨ Features

- 🔍 **Unified full-text search** across SharePoint, Confluence, and Jira with relevance scoring
- 🔄 **Incremental sync** — only new or changed documents are upserted on each run
- 📊 **Live dashboard** with per-source document counts, sync status, and activity log
- 🏷️ **Source filtering** — narrow search results to one platform instantly
- 📄 **Document browser** — paginated list view of all indexed content
- 🔗 **Deep links** — every result links back to the original document in its source system
- ⏱️ **Auto-sync scheduler** — runs in the background on a configurable interval
- 🛡️ **ServiceNow stub** — connector scaffolding ready for future implementation
- 📖 **Interactive API docs** — Swagger UI at `/docs`, ReDoc at `/redoc`

---

## 🏗️ Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│                         EKM Architecture                            │
├──────────────┬────────────────┬──────────────┬──────────┬──────────┤
│ DATA SOURCES │  CONNECTORS    │  CORE ENGINE │   API    │FRONTEND  │
├──────────────┼────────────────┼──────────────┼──────────┼──────────┤
│ SharePoint ──┼─ sharepoint.py │              │ /search  │Dashboard │
│ Confluence ──┼─ confluence.py ┼─ sync_svc ──┼─ /sync   │Search    │
│ Jira ────────┼─ jira.py       │   MongoDB    │ /sources │Documents │
│ ServiceNow* ─┼─ (stub)        │   Indexes    │ /docs    │          │
└──────────────┴────────────────┴──────────────┴──────────┴──────────┘
                                                    * future scope
```

![Architecture Diagram](docs/architecture.png)

### Data Flow

1. **Connector** authenticates to source system (MSAL for SharePoint, API token for Confluence/Jira)
2. Connector fetches documents and normalises them into a common `Document` schema
3. **Sync service** upserts each document into MongoDB using a compound unique key `(source_type, external_id)`
4. MongoDB **text indexes** on `title`, `content`, and `tags` enable fast full-text search
5. **FastAPI** routes expose search, sync, and browse endpoints
6. **React frontend** calls the API and renders results with source badges, relevance scores, and deep links

---

## 📁 Project Structure

```
ekm-mvp/
│
├── start-backend.sh / .bat      ← one-command backend startup
├── start-frontend.sh / .bat     ← one-command frontend startup
├── .env.example                 ← copy to backend/.env
├── docs/
│   └── architecture.png         ← system architecture diagram
│
├── backend/
│   ├── main.py                  ← FastAPI app, lifespan, CORS, scheduler
│   ├── config.py                ← Pydantic settings from .env
│   ├── database.py              ← Async MongoDB connection + index creation
│   ├── models.py                ← All Pydantic schemas (Document, SyncLog, etc.)
│   │
│   ├── connectors/
│   │   ├── sharepoint.py        ← MSAL auth → Microsoft Graph API
│   │   ├── confluence.py        ← Atlassian Python API, HTML → plain text
│   │   ├── jira.py              ← Atlassian API, ADF → plain text, comments
│   │   └── servicenow.py        ← STUB with full implementation notes
│   │
│   ├── routes/
│   │   ├── search.py            ← Full-text search with relevance scoring
│   │   └── api.py               ← Sync, sources/stats, document CRUD
│   │
│   └── utils/
│       └── sync_service.py      ← Orchestrates all connectors, upserts to DB
│
└── frontend/
    ├── package.json
    ├── vite.config.js           ← Dev server + /api proxy to :8000
    ├── tailwind.config.js
    └── src/
        ├── App.jsx              ← Layout shell, sidebar, React Router
        ├── api.js               ← Axios client, all API calls
        ├── index.css            ← Tailwind base + component classes
        │
        ├── pages/
        │   ├── Dashboard.jsx    ← Stat cards, source cards, sync buttons, activity log
        │   ├── Search.jsx       ← Search bar, filters, results, doc modal
        │   └── Documents.jsx    ← Paginated document browser with source filter
        │
        └── components/
            └── UI.jsx           ← SourceBadge, StatusBadge, DocCard, StatCard, Spinner
```

---

## ⚡ Quick Start

### Prerequisites

| Tool | Version | Install |
|------|---------|---------|
| Python | 3.11+ | [python.org](https://python.org) |
| Node.js | 18+ | [nodejs.org](https://nodejs.org) |
| MongoDB | Any | Your existing instance |

### 1 — Clone

```bash
git clone https://github.com/YOUR_USERNAME/ekm-mvp.git
cd ekm-mvp
```

### 2 — Configure

```bash
cp .env.example backend/.env
```

Edit `backend/.env` — at minimum set your MongoDB URI and one set of source credentials (see [Configuration](#-configuration)).

### 3 — Start backend

```bash
# Mac / Linux
chmod +x start-backend.sh
./start-backend.sh

# Windows
start-backend.bat
```

Backend: **http://localhost:8000** · API docs: **http://localhost:8000/docs**

### 4 — Start frontend _(new terminal)_

```bash
# Mac / Linux
chmod +x start-frontend.sh
./start-frontend.sh

# Windows
start-frontend.bat
```

Frontend: **http://localhost:3000**

### 5 — Sync and search

Click **Sync All** on the Dashboard, wait for the sync to complete, then go to **Search** and start querying.

---

## ⚙️ Configuration

All configuration lives in `backend/.env`. Copy `.env.example` to get started.

### MongoDB

```env
# No auth (standard local setup)
MONGO_URI=mongodb://localhost:27017/ekm

# With username/password
MONGO_URI=mongodb://username:password@localhost:27017/ekm?authSource=admin

# MongoDB Atlas
MONGO_URI=mongodb+srv://username:password@cluster.mongodb.net/ekm
```

### SharePoint

```env
SHAREPOINT_TENANT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
SHAREPOINT_CLIENT_ID=xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx
SHAREPOINT_CLIENT_SECRET=your~client~secret
SHAREPOINT_SITE_URL=https://yourorg.sharepoint.com/sites/yoursite
```

### Confluence

```env
CONFLUENCE_URL=https://yourorg.atlassian.net
CONFLUENCE_USERNAME=you@yourorg.com
CONFLUENCE_API_TOKEN=your_api_token
CONFLUENCE_SPACES=ENG,HR,PROD   # comma-separated; leave blank to sync all spaces
```

### Jira

```env
JIRA_URL=https://yourorg.atlassian.net
JIRA_USERNAME=you@yourorg.com
JIRA_API_TOKEN=your_api_token   # same token as Confluence
JIRA_PROJECTS=ENG,OPS,INFRA     # comma-separated; leave blank to sync all projects
```

### App Settings

```env
SYNC_INTERVAL_MINUTES=60   # how often to auto-sync (default: 60)
MAX_RESULTS_PER_PAGE=20    # search results per page (default: 20)
```

---

## 🔑 Getting Credentials

### SharePoint — Azure App Registration

1. Go to **[Azure Portal](https://portal.azure.com) → App registrations → New registration**
2. Name it (e.g. `ekm-connector`), select **Single tenant**, click Register
3. Go to **API permissions → Add a permission → Microsoft Graph → Application permissions**
4. Add: `Sites.Read.All` and `Files.Read.All`
5. Click **Grant admin consent for [your org]**
6. Go to **Certificates & secrets → New client secret**, copy the value
7. Copy **Tenant ID** and **Application (client) ID** from the Overview page

### Confluence & Jira — Atlassian API Token

1. Go to **[Atlassian Account Security](https://id.atlassian.com/manage-profile/security/api-tokens)**
2. Click **Create API token**, give it a label, copy the token
3. Use your Atlassian account email + this token for both Confluence and Jira

> **One token works for both Confluence and Jira** if they are on the same Atlassian account.

---

## 🚀 Running the App

### Manual startup (without scripts)

**Backend:**
```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate.bat
pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

**Frontend:**
```bash
cd frontend
npm install
npm run dev
```

### Trigger a sync manually

```bash
# Sync all sources
curl -X POST http://localhost:8000/api/sync

# Sync one source only
curl -X POST http://localhost:8000/api/sync \
     -H "Content-Type: application/json" \
     -d '{"source_type": "confluence"}'
```

---

## 📡 API Reference

| Method | Endpoint | Description |
|--------|----------|-------------|
| `GET` | `/api/health` | Health check — returns version |
| `GET` | `/api/search?q={query}` | Full-text search across all sources |
| `GET` | `/api/search?q={query}&source_type=jira` | Search filtered to one source |
| `GET` | `/api/search?q={query}&page=2` | Paginated search results |
| `GET` | `/api/sources` | Dashboard stats — doc counts, sync status per source |
| `POST` | `/api/sync` | Trigger sync — all sources (empty body) |
| `POST` | `/api/sync` | Trigger sync — one source `{"source_type": "sharepoint"}` |
| `GET` | `/api/sync/logs` | Recent sync history (last 20 entries) |
| `GET` | `/api/documents` | Browse all documents (paginated) |
| `GET` | `/api/documents?source_type=jira` | Browse filtered by source |
| `GET` | `/api/documents/{id}` | Single document with full content |

Full interactive docs: **http://localhost:8000/docs**

### Example: Search Response

```json
{
  "query": "deployment process",
  "total": 47,
  "page": 1,
  "page_size": 20,
  "results": [
    {
      "id": "64f2a1b3...",
      "source_type": "confluence",
      "source": "Confluence / ENG",
      "title": "Production Deployment Runbook",
      "content_preview": "This runbook covers the steps required to deploy...",
      "url": "https://yourorg.atlassian.net/wiki/...",
      "author": "Jane Smith",
      "tags": ["confluence", "eng", "deployment"],
      "score": 8.42,
      "ingested_at": "2024-06-01T10:30:00Z"
    }
  ]
}
```

---

## 🧩 Code Walkthrough

### Document Model (`backend/models.py`)

Every document from every source is normalised into a single schema before storage:

```python
class Document(BaseModel):
    external_id: str        # original ID from source system
    source_type: SourceType # sharepoint | confluence | jira
    source: str             # human label e.g. "Confluence / ENG"
    title: str
    content: str            # plain text — HTML stripped by connectors
    url: str                # deep link back to original
    author: Optional[str]
    tags: list[str]         # source + space/project + labels
    metadata: dict          # source-specific fields (issue type, status, etc.)
    ingested_at: datetime
    updated_at: Optional[datetime]
```

### MongoDB Indexes (`backend/database.py`)

```python
# Full-text search with field weighting
IndexModel([("title", TEXT), ("content", TEXT), ("tags", TEXT)],
           weights={"title": 10, "tags": 5, "content": 1})

# Unique upsert key — prevents duplicates across syncs
IndexModel([("source_type", ASCENDING), ("external_id", ASCENDING)],
           unique=True)
```

### Sync Service (`backend/utils/sync_service.py`)

Each sync run:
1. Calls the connector's `fetch_documents()` coroutine
2. Upserts each document using `update_one(..., upsert=True)` — so re-syncing is always safe
3. Writes a `SyncLog` entry with status, counts, and any error message
4. Returns a summary dict for the API response

### SharePoint Connector (`backend/connectors/sharepoint.py`)

Uses **MSAL client credentials flow** (app-only auth — no user login required):
```
Azure AD App → acquire_token_for_client() → Bearer token
→ GET /sites/{site_id}/pages
→ GET /sites/{site_id}/drive/root/children
```

### Confluence Connector (`backend/connectors/confluence.py`)

Uses **Atlassian Python API** with basic auth. Strips Confluence storage format HTML to plain text using regex before storing. Supports pagination via `start` / `limit`.

### Jira Connector (`backend/connectors/jira.py`)

Fetches issues via JQL: `project = {KEY} ORDER BY updated DESC`. Handles:
- **Atlassian Document Format (ADF)** — Jira Cloud's rich text JSON — recursively extracted to plain text
- **Comments** — concatenated and included in the indexed content
- **Metadata** — issue type, status, priority, assignee, components stored in `metadata` field

---

## 📸 Screenshots

### Dashboard
> Live source cards showing document counts, sync status, and recent activity

### Search
> Full-text search across all sources with relevance scoring, source filters, and document preview modal

### Documents
> Paginated browser of all indexed documents, filterable by source

---

## 🗺️ Roadmap & Next Steps

### Phase 2 — Search Quality
- [ ] **Vector / semantic search** — embed documents with OpenAI or a local model, store in MongoDB Atlas Vector Search or a separate vector DB
- [ ] **Query suggestions** — autocomplete based on indexed titles and tags
- [ ] **Highlighted snippets** — show the matching passage, not just the first 300 chars

### Phase 3 — Access & Security
- [ ] **User authentication** — SSO via Azure AD / Okta
- [ ] **Per-user permissions** — respect source system ACLs so users only see what they can access
- [ ] **Audit logging** — track who searched for what

### Phase 4 — More Sources
- [ ] **ServiceNow** — connector stub is already in place at `connectors/servicenow.py`
- [ ] **Google Drive / Workspace**
- [ ] **GitHub / GitLab** — index READMEs, wikis, and issues
- [ ] **Slack** — index public channel messages and files

### Phase 5 — Intelligence
- [ ] **AI-powered answers** — RAG (Retrieval Augmented Generation) on top of the indexed corpus
- [ ] **Knowledge graph** — map relationships between documents, people, and topics
- [ ] **Duplicate detection** — identify and merge near-duplicate content across sources

---

## 🤝 Contributing

1. Fork the repo
2. Create a feature branch: `git checkout -b feature/your-feature`
3. Commit your changes: `git commit -m 'Add your feature'`
4. Push: `git push origin feature/your-feature`
5. Open a Pull Request

Please follow the existing code style and add a connector for a new source by copying the pattern from `connectors/confluence.py`.

---

## 📄 License

MIT — see [LICENSE](LICENSE) for details.

---

<div align="center">
Built as an MVP · ServiceNow integration coming in Phase 4
</div>
