#!/bin/bash
# ─── Push EKM MVP to GitHub ───────────────────────────────────────────────────
# Run this once from inside the ekm-mvp folder

set -e

TOKEN="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"

# ── 1. Get your GitHub username ───────────────────────────────────────────────
echo "→ Fetching your GitHub username..."
USERNAME=$(curl -s -H "Authorization: token $TOKEN" \
  https://api.github.com/user | python3 -c \
  "import sys,json; print(json.load(sys.stdin)['login'])")

echo "✓ Logged in as: $USERNAME"

# ── 2. Create the repo ────────────────────────────────────────────────────────
echo "→ Creating repo 'ekm-mvp' on GitHub..."
curl -s -X POST \
  -H "Authorization: token $TOKEN" \
  -H "Content-Type: application/json" \
  https://api.github.com/user/repos \
  -d '{
    "name": "ekm-mvp",
    "description": "Enterprise Knowledge Management MVP — unified search across SharePoint, Confluence & Jira",
    "private": false,
    "auto_init": false
  }' | python3 -c "import sys,json; d=json.load(sys.stdin); print('✓ Repo created:', d.get('html_url','(check GitHub)'))"

# ── 3. Push ───────────────────────────────────────────────────────────────────
echo "→ Pushing code..."
git remote remove origin 2>/dev/null || true
git remote add origin "https://$USERNAME:$TOKEN@github.com/$USERNAME/ekm-mvp.git"
git push -u origin main

echo ""
echo "╔══════════════════════════════════════════════════════╗"
echo "║  ✅ Done! Your repo is live at:                      ║"
echo "║  https://github.com/$USERNAME/ekm-mvp"
echo "╚══════════════════════════════════════════════════════╝"
