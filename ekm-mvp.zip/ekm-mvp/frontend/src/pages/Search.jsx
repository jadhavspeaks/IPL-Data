import { useState, useCallback } from 'react'
import { searchDocs } from '../api'
import { DocCard, SourceBadge, EmptyState, Spinner } from '../components/UI'
import { Search, X, ExternalLink } from 'lucide-react'

const SOURCES = ['sharepoint', 'confluence', 'jira']

export default function SearchPage() {
  const [query, setQuery] = useState('')
  const [sourceFilter, setSourceFilter] = useState('')
  const [results, setResults] = useState(null)
  const [loading, setLoading] = useState(false)
  const [page, setPage] = useState(1)
  const [selectedDoc, setSelectedDoc] = useState(null)

  const doSearch = useCallback(async (q = query, src = sourceFilter, p = 1) => {
    if (!q.trim()) return
    setLoading(true)
    try {
      const res = await searchDocs(q, src, p)
      setResults(res.data)
      setPage(p)
    } catch (e) {
      console.error(e)
    } finally {
      setLoading(false)
    }
  }, [query, sourceFilter])

  const handleKey = (e) => {
    if (e.key === 'Enter') doSearch()
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-gray-900">Search</h1>
        <p className="text-gray-500 text-sm mt-0.5">Search across SharePoint, Confluence, and Jira</p>
      </div>

      {/* Search bar */}
      <div className="card p-4 space-y-3">
        <div className="flex gap-3">
          <div className="relative flex-1">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              className="w-full pl-9 pr-4 py-2.5 border border-gray-200 rounded-lg text-sm focus:outline-none focus:ring-2 focus:ring-teal-400"
              placeholder="Search knowledge base..."
              value={query}
              onChange={e => setQuery(e.target.value)}
              onKeyDown={handleKey}
            />
            {query && (
              <button onClick={() => { setQuery(''); setResults(null) }}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600">
                <X size={14} />
              </button>
            )}
          </div>
          <button className="btn-primary px-6" onClick={() => doSearch()}>
            Search
          </button>
        </div>

        {/* Source filters */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-gray-500">Filter:</span>
          <button
            onClick={() => { setSourceFilter(''); doSearch(query, '') }}
            className={`badge cursor-pointer transition-colors ${!sourceFilter ? 'bg-teal-100 text-teal-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
          >
            All sources
          </button>
          {SOURCES.map(src => (
            <button key={src}
              onClick={() => { setSourceFilter(src); doSearch(query, src) }}
              className={`badge cursor-pointer transition-colors ${sourceFilter === src ? 'bg-teal-100 text-teal-700' : 'bg-gray-100 text-gray-600 hover:bg-gray-200'}`}
            >
              {src}
            </button>
          ))}
        </div>
      </div>

      {/* Results */}
      {loading && (
        <div className="flex justify-center py-12">
          <Spinner />
        </div>
      )}

      {!loading && results && (
        <>
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-500">
              <span className="font-semibold text-gray-900">{results.total.toLocaleString()}</span> results for "<span className="italic">{results.query}</span>"
            </p>
          </div>

          {results.results.length === 0 ? (
            <EmptyState icon="🔍" title="No results found" subtitle="Try different keywords or remove the source filter." />
          ) : (
            <div className="grid md:grid-cols-2 gap-3">
              {results.results.map(doc => (
                <DocCard key={doc.id} doc={doc} onClick={setSelectedDoc} />
              ))}
            </div>
          )}

          {/* Pagination */}
          {results.total > results.page_size && (
            <div className="flex justify-center gap-2 pt-2">
              <button className="btn-secondary text-sm" disabled={page === 1}
                onClick={() => doSearch(query, sourceFilter, page - 1)}>
                Previous
              </button>
              <span className="flex items-center px-4 text-sm text-gray-500">
                Page {page} of {Math.ceil(results.total / results.page_size)}
              </span>
              <button className="btn-secondary text-sm"
                disabled={page >= Math.ceil(results.total / results.page_size)}
                onClick={() => doSearch(query, sourceFilter, page + 1)}>
                Next
              </button>
            </div>
          )}
        </>
      )}

      {!loading && !results && (
        <EmptyState icon="💡" title="Start searching" subtitle="Type a keyword above to search across all your connected knowledge sources." />
      )}

      {/* Document detail modal */}
      {selectedDoc && (
        <div className="fixed inset-0 bg-black/40 z-50 flex items-center justify-center p-4"
          onClick={() => setSelectedDoc(null)}>
          <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full max-h-[80vh] overflow-y-auto p-6"
            onClick={e => e.stopPropagation()}>
            <div className="flex items-start justify-between gap-3 mb-4">
              <div>
                <SourceBadge type={selectedDoc.source_type} />
                <h2 className="text-lg font-bold text-gray-900 mt-2">{selectedDoc.title}</h2>
                <p className="text-xs text-gray-400 mt-0.5">{selectedDoc.source} {selectedDoc.author && `· ${selectedDoc.author}`}</p>
              </div>
              <button onClick={() => setSelectedDoc(null)}
                className="text-gray-400 hover:text-gray-600">
                <X size={20} />
              </button>
            </div>

            <p className="text-gray-600 text-sm leading-relaxed whitespace-pre-line">
              {selectedDoc.content_preview}
            </p>

            <div className="flex items-center gap-3 mt-6 pt-4 border-t border-gray-100">
              <a href={selectedDoc.url} target="_blank" rel="noopener noreferrer"
                className="btn-primary flex items-center gap-2 text-sm">
                <ExternalLink size={14} />
                Open in Source
              </a>
              <button onClick={() => setSelectedDoc(null)} className="btn-secondary text-sm">
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
