#!/bin/bash
# ─── EKM Backend — Local Setup & Run ─────────────────────────────────────────
set -e

cd "$(dirname "$0")/backend"

echo ""
echo "╔══════════════════════════════════════╗"
echo "║   EKM Backend — Local Setup          ║"
echo "╚══════════════════════════════════════╝"
echo ""

# ── 1. Check Python version ───────────────────────────────────────────────────
PYTHON=$(command -v python3 || command -v python)
PY_VERSION=$($PYTHON --version 2>&1)
echo "✓ Using $PY_VERSION"

# ── 2. Create virtual environment if it doesn't exist ────────────────────────
if [ ! -d "venv" ]; then
  echo "→ Creating virtual environment..."
  $PYTHON -m venv venv
fi

# ── 3. Activate venv ─────────────────────────────────────────────────────────
source venv/bin/activate
echo "✓ Virtual environment activated"

# ── 4. Install dependencies ───────────────────────────────────────────────────
echo "→ Installing dependencies..."
pip install -q --upgrade pip
pip install -q -r requirements.txt
echo "✓ Dependencies installed"

# ── 5. Check .env ─────────────────────────────────────────────────────────────
if [ ! -f ".env" ]; then
  echo ""
  echo "⚠️  No .env file found in backend/"
  echo "   Copy ../.env.example to backend/.env and fill in your credentials"
  echo ""
  cp ../.env.example .env
  echo "→ Created backend/.env from template — please edit it before continuing"
  exit 1
fi
echo "✓ .env found"

# ── 6. Start the API ──────────────────────────────────────────────────────────
echo ""
echo "→ Starting FastAPI on http://localhost:8000"
echo "   API docs: http://localhost:8000/docs"
echo ""
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
